import os, json
from fastapi import FastAPI
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI(title="ELI Sync Gateway")
state = {"messages": [], "tasks": []}
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY")) if os.getenv("OPENAI_API_KEY") else None

class SyncBody(BaseModel):
    messages: list = []
    tasks: list = []

class ChatBody(BaseModel):
    message: str

@app.get("/health")
def health():
    return {"ok": True, "service": "eli"}

@app.get("/sync")
def get_sync():
    return state

@app.post("/sync")
def set_sync(body: SyncBody):
    state["messages"] = body.messages
    state["tasks"] = body.tasks
    return {"ok": True}

@app.post("/chat")
def chat(body: ChatBody):
    if not client:
        return {"answer": "The ELI server is connected, but OPENAI_API_KEY has not been configured."}
    response = client.chat.completions.create(
        model="gpt-5.6-mini",
        messages=[
            {"role":"system","content":"You are ELI, a concise futuristic work assistant. Help the user stay productive."},
            {"role":"user","content":body.message}
        ],
    )
    return {"answer": response.choices[0].message.content}
