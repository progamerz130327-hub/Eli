# ELI Cross-Platform

This package adds an Android Flutter client and a small sync/AI gateway.

## Mobile
Install Flutter, then from `mobile`:
flutter pub get
flutter run

Build an Android APK:
flutter build apk --release

## Sync server
On the Windows PC/server:
1. Set OPENAI_API_KEY.
2. Open `server` in PowerShell.
3. Run `py -m pip install -r requirements.txt`.
4. Run `py -m uvicorn main:app --host 0.0.0.0 --port 8000`.
5. On the phone, open ELI Settings and enter the PC's local IP, for example:
   http://192.168.1.25:8000

For internet syncing, host the gateway on a secure HTTPS server rather than exposing a home PC directly.

## Important
The included gateway stores state in memory for this starter build. Restarting it clears that state. A production version should use a real database plus authentication/encryption.
